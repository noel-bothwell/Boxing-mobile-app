package ie.wit.assignment1.models

import java.util.*

data class BoxerArray1 (
    var name: String = "",
    var numberWins: Int =0,
    var numberlosses: Int =0,
    var weightClass: String ="" ,
    var isRetired: Boolean=true,
    var birthDate: String = ""
    )

